package com.cognizant.companyservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cognizant.companyservice.model.Company;
import com.cognizant.companyservice.model.Role;

public interface CompanyRepository extends JpaRepository<Company,Integer>{

}
