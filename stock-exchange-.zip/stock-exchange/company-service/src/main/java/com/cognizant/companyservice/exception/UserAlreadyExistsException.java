package com.cognizant.companyservice.exception;

public class UserAlreadyExistsException extends Exception {

}
