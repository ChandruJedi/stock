package com.cognizant.companyservice.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.companyservice.model.Company;
import com.cognizant.companyservice.repository.CompanyRepository;

@Service
public class CompanyService {
	@Autowired CompanyRepository companyRepository;
	public List<Company> getCompanies() {
		return this.companyRepository.findAll();
	}
}
