package com.cognizant.companyservice.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "company")
public class Company {

	@Id
	@Column(name = "co_id")
	private int id;
	@Column(name="co_name")
	private String name;
	@Column(name = "co_turnover")
	private float turnOver;
	@Column(name = "co_ceo")
	private String ceo;
	@Column(name = "co_sector")
	private String sector;
	@Column(name = "co_stock_exchange")
	private String stockExchange;
	@Column(name="co_bod")
	private String boardOfDirectors;
	@Column(name = "co_brief")
	private String briefWriteup;
	@Column(name="co_active")
	private boolean active;
	@Column(name="co_code")
	private String stockCode;
	
	public String getSector() {
		return sector;
	}
	public void setSector(String sector) {
		this.sector = sector;
	}
	public String getStockExchange() {
		return stockExchange;
	}
	public void setStockExchange(String stockExchange) {
		this.stockExchange = stockExchange;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getTurnOver() {
		return turnOver;
	}
	public void setTurnOver(float turnOver) {
		this.turnOver = turnOver;
	}
	public String getCeo() {
		return ceo;
	}
	public void setCeo(String ceo) {
		this.ceo = ceo;
	}
	public String getBoardOfDirectors() {
		return boardOfDirectors;
	}
	public void setBoardOfDirectors(String boardOfDirectors) {
		this.boardOfDirectors = boardOfDirectors;
	}
	public String getBriefWriteup() {
		return briefWriteup;
	}
	public void setBriefWriteup(String briefWriteup) {
		this.briefWriteup = briefWriteup;
	}
	public boolean isActive() {
		return active;
	}
	public void setActive(boolean active) {
		this.active = active;
	}

	public String getStockCode() {
		return stockCode;
	}
	public void setStockCode(String stockCode) {
		this.stockCode = stockCode;
	}
	@Override
	public String toString() {
		return "Company [id=" + id + ", name=" + name + ", turnOver=" + turnOver + ", ceo=" + ceo
				+ ", boardOfDirectors=" + boardOfDirectors + ", briefWriteup=" + briefWriteup + ", active=" + active
				+ ", stockCode=" + stockCode + "]";
	}

}
