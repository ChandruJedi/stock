package com.cognizant.companyservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cognizant.companyservice.model.StockPrice;


public interface StockPriceRepository extends JpaRepository<StockPrice,Integer> {

}
