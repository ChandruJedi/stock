import { Component, OnInit } from '@angular/core';
import { UserService } from '../services/user.service';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Summary } from '../summary';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  form: FormGroup;
  error: string;
  userId: number = 1;
  uploadResponse = { status: '', message: '', filePath: '' };
  uploaded: boolean = false;
  companies: any;
  summary: Summary;

  constructor(private formBuilder: FormBuilder, private userService: UserService) { }
  ngOnInit() {
    this.form = this.formBuilder.group({
      avatar: ['']
    });
    this.userService.getCompanies().subscribe(data => {
      this.companies = data;
    })
    this.userService.getSummary().subscribe(
      (ress) => { this.summary = ress;
        console.log(this.summary)
                  
                   },
      (err) => this.error = err);
  }
  onFileChange(event) {
    if (event.target.files.length > 0) {
      const file = event.target.files[0];
      this.form.get('avatar').setValue(file);
    }
  }

  onSubmit() {
    const formData = new FormData();
    formData.append('file', this.form.get('avatar').value);

    this.userService.uploadExcel(formData).subscribe(
      (res) => { this.uploadResponse = res;
        this.uploaded = true; },
      (err) => this.error = err,

    );
  }

}
