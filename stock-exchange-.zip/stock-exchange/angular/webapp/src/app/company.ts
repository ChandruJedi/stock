export interface Company{
    id?:number;
    name:string;
    turnOver:number;
    ceo:string;
    sector:string;
    stockExchange:string;
    boardOfDirectors:string;
    briefWriteup:string;
    active:boolean;
    stockCode:string;
}