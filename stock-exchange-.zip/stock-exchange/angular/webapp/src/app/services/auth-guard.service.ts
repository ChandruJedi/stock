import { Injectable } from '@angular/core';
import { Router, RouterStateSnapshot, ActivatedRouteSnapshot, UrlTree } from '@angular/router';
import { Observer, Observable } from 'rxjs';
import { AuthenticationService } from './authentication-service.service';

@Injectable({
  providedIn: 'root'
})
export class AuthGuardService {
  constructor(private authService: AuthenticationService, private router: Router) { }
  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree{
    this.authService.navUrl = state.url;
    console.log('URL', state.url);
    return Observable.create((observer: Observer<boolean>)=>{
      if(this.authService.isLoggedIn){
        console.log('Logged In');
        observer.next(true);
      } else {
        console.log('Logged Out');
        this.router.navigate(['login'],{ queryParams:{from: state.url.substr(1)}});
      }
    })
  }
}
