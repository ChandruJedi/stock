import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {
  private token:string;
  isLoggedIn:boolean=false;
   private authenticationApiUrl = environment.baseUrl+'/authenticate';
   navUrl: string;
  user: string;
   constructor(private httpClient: HttpClient) { }
 
   authenticate(user: string, password: string): Observable<any> {
    this.user=user;
     this.isLoggedIn=true;
     let credentials = btoa(user + ':' + password);
     let headers = new HttpHeaders();
     headers = headers.set('Authorization', 'Basic ' + credentials);
     console.log(this.httpClient.get(this.authenticationApiUrl, { headers }));
     return this.httpClient.get(this.authenticationApiUrl, { headers });
   }
   logOut(){
    this.navUrl='/';
    this.isLoggedIn=false;
  }
   public setToken(token: string) {
     this.token = token;
   }

   public getToken() {
     console.log(this.token);
     return this.token;
   }
}
