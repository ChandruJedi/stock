import { Injectable } from '@angular/core';
import { Bill } from '../bill';

@Injectable({
  providedIn: 'root'
})
export class UserAuthService {
  loggedIn = false;
  private role: string;
  private user: string;
  serviceType: String;
  billTrue: boolean;
  constructor() { }

  public setRole(role: string) {
    this.role = role;
  }
  public getRole() {
    return this.role;
  }
  public setUser(user: string) {
    this.user = user;
  }
  public getUser() {
    return this.user;
  }
  public getLoggedIn(){
    return this.loggedIn;
  }
  public setLoggedIn(logg:boolean){
    this.loggedIn=logg;
  }
  

}
