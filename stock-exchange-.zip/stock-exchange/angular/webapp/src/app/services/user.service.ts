import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from '../site/user';
import { Bill } from '../bill';
import { AuthenticationService } from './authentication-service.service';
import { Company } from '../company';
import { Summary } from '../summary';


@Injectable({
  providedIn: 'root'
})
export class UserService {
  baseUrl = environment.baseUrl;
  signupUrl="http://localhost:8095/authentication-service/users";
  importExcel = "http://localhost:8095/admin-service/import";
  companyUrl="http://localhost:8095/company-service/company"
  constructor(private httpClient: HttpClient, private authenticationService: AuthenticationService) { }
  addUser(user: User): Observable<void> {
    return this.httpClient.post<void>("http://localhost:8095/authentication-service/users", user);
  }
  public uploadExcel(data) {
    return this.httpClient.post<any>(this.importExcel, data);
  }
  getUser(username: string):Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + this.authenticationService.getToken()
      })
    };
    console.log(this.authenticationService.getToken());
    return this.httpClient.get<User>(this.signupUrl+"/"+username,httpOptions);
  }
  getCompanies():Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + this.authenticationService.getToken()
      })
    };
    return this.httpClient.get<Company>(this.companyUrl,httpOptions);
  }
  getSummary():Observable<any>{
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + this.authenticationService.getToken()
      })
    };
    return this.httpClient.get<Summary>(this.importExcel,httpOptions);
  }
}
