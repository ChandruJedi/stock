export interface Summary{
    name:string;
    stock:number;
    startDate:Date;
    endDate:Date;
    length:number;
}