import { Component, OnInit } from '@angular/core';
import { UserService } from '../services/user.service';
import { Company } from '../company';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  companyList: Company[];
  companies: Company[];
  searchitem:boolean=false;

  constructor(private userService:UserService) { }
  
  ngOnInit() {
    this.userService.getCompanies().subscribe(data=>{
      this.companies=data;
    })
  }
  search(event: any) {
    this.companyList = this.companies.filter(product=>{
      this.searchitem=true;
      let isNameSimilar = product.name.toLocaleLowerCase().includes(event.target.value.toLocaleLowerCase());
      return isNameSimilar;
    });
  }
}
