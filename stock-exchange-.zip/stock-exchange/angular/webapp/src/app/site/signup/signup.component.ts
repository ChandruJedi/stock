import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { UserService } from 'src/app/services/user.service';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { UserAuthService } from 'src/app/services/user-auth.service';
import { User } from '../user';
import { AuthenticationService } from 'src/app/services/authentication-service.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  detailForm: FormGroup;
  userForm: FormGroup;
  // form: NgForm;
  user: User;
  nextStatus: Boolean = false;
  userPresent: boolean = false;
  byDefault: boolean = false;
  error: string;
  signupformValidation: boolean;
  vendorForm: FormGroup;
  newUser: boolean;
  signupSuccess: boolean;
  users: boolean=false;
  update: boolean;
  signupForm: any;

  constructor(private userService: UserService, private router: Router,private userAuthService: UserAuthService, private route: ActivatedRoute, private authService: AuthenticationService) { }

  ngOnInit() {
    this.users=this.userAuthService.loggedIn;
    console.log(this.users)
    this.detailForm = new FormGroup({
      id: new FormControl(null),
      username: new FormControl(null, [Validators.required, Validators.pattern('^[a-z A-Z]*')]),
      email: new FormControl(null, [Validators.required, Validators.pattern('[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$')]),
      mobile: new FormControl(null, [Validators.required, Validators.pattern('^[0-9+]*'), Validators.maxLength(13)]),
      password: new FormControl(null, [Validators.required]),
      confirmPassword: new FormControl(null, [Validators.required]),
      role: new FormControl(null),
    });
    this.route.params.subscribe((params: Params) => {
      const username = params['username'];
      console.log(username);
      this.userService.getUser(username).subscribe((user) => {
        if (user) {
          console.log(username);
          this.update=true;
          this.detailForm.patchValue({
            id: user.id,
            username:username,
            email: user.email,
            mobile: user.mobile,
          });
        }
      })
    })
  }
  get username() { return this.detailForm.get('username') }
  get email() { return this.detailForm.get('email') }
  get mobile() { return this.detailForm.get('mobile') }
  get password() { return this.detailForm.get('password') }
  get confirmPassword() { return this.detailForm.get('confirmPassword') }

  isConfirmPasswordValid() {
    if ((this.detailForm.get('password').value != null) && this.detailForm.get('confirmPassword').value != null) {
      if ((this.detailForm.get('password').value != this.detailForm.get('confirmPassword').value)) {
        return true;
      } else {
        return false;
      }
    }
  }

  onSubmit() {
    this.user = this.detailForm.value;
    console.log(this.user);
    if (this.detailForm.value.password != this.detailForm.value.confirmPassword) {
      this.signupformValidation = true;
    }
    else {
      console.log(this.detailForm.value.username);
     this.userService.addUser(this.user).subscribe(
        (response) => {
          console.log(this.detailForm.value.username);
          this.signupSuccess=true;
          this.userAuthService.setUser(this.detailForm.value.username);
          this.newUser=true;
        },
        (responseError) => {
          this.error = responseError.error.errorMessage;
          this.userPresent = true;
        }
      );
    }
  }
  passwordChanged(event){
    this.router.navigate(['user']);
  }
  successValid(event){
    this.router.navigate(['login']);
  }
  

}
