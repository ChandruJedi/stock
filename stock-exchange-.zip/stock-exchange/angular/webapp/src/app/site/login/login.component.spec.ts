import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HttpClient, HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { routes } from 'src/app/app.module';
import { SignupComponent } from '../signup/signup.component';
import { AppComponent } from 'src/app/app.component';
import { AdminComponent } from 'src/app/admin/admin.component';
import { UserComponent } from 'src/app/user/user.component';
import { LoginComponent } from './login.component';
import { HeaderComponent } from 'src/app/home/header/header.component';

fdescribe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [   AppComponent,
        LoginComponent,
        SignupComponent,
        HeaderComponent,
        AdminComponent,
        UserComponent,],
      imports:[  FormsModule,
        HttpClientModule,
        ReactiveFormsModule,
        RouterModule.forRoot(routes)]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('created a form with username and password input and login button', () => {
    const usernameContainer = fixture.debugElement.nativeElement.querySelector('#userName');
    const passwordContainer = fixture.debugElement.nativeElement.querySelector('#inputPassword');
    const loginBtnContainer = fixture.debugElement.nativeElement.querySelector('#login');
    expect(usernameContainer).toBeDefined();
    expect(passwordContainer).toBeDefined();
    expect(loginBtnContainer).toBeDefined();
  });
});
