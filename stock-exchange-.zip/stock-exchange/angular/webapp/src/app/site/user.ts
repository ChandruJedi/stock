export interface User{
    id: number;
    username:string;
    // role:string;
    password:string;
    mobile:string,
    email:string,
    confirmed?:boolean,

}