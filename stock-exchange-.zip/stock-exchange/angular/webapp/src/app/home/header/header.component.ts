import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from 'src/app/services/authentication-service.service';
import { UserAuthService } from 'src/app/services/user-auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  clicked: boolean=true;
  isAdmin: boolean=false;
  checkNav:boolean=false;
  isUser: boolean;
  constructor(private authService: AuthenticationService,private userAuthService:UserAuthService,private router: Router) { 
    
  }

  ngOnInit() {
    
  }
  clickedNav(){
    this.clicked=false;
  }
  authenticated(){
    console.log(this.authService.isLoggedIn);
    this.checkNav=this.userAuthService.getLoggedIn();
    if(this.userAuthService.getRole()=='USER'){
      this.isUser=true;
    }
    console.log(this.userAuthService.getRole())
    return this.checkNav;
  }
  getUser(){
    return this.userAuthService.getUser();
  }

  username(){
    console.log(this.authService.user);
    return this.authService.user;
  }
  
  signOut(){
    this.userAuthService.setLoggedIn(false);
    this.authService.setToken(null);
    // this.favService.clearFav();
    this.authService.logOut();
    this.router.navigate([this.authService.navUrl]);
    this.userAuthService.setRole(null);
    this.userAuthService.setUser(null);
  }

}
