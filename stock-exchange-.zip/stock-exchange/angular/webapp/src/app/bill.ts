export interface Bill{
    name:String,
    number:String,
    amount:String,
    date:Date
}