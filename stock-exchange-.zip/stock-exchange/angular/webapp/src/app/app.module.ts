import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './site/login/login.component';
import { DatePipe } from '@angular/common';
import { UserComponent } from './user/user.component';
import { AuthGuardService } from './auth-guard.service';
import { AdminComponent } from './admin/admin.component';
import { SignupComponent } from './site/signup/signup.component';
import { SampleComponent } from './sample/sample.component';
import { HeaderComponent } from './home/header/header.component';



export const routes: Routes =
  [
    {path: 'login', component: LoginComponent},
    {path: 'admin', component: AdminComponent, canActivate:[AuthGuardService]},
    {path: 'signup', component: SignupComponent},
    {path: 'user', component: UserComponent, canActivate:[AuthGuardService]},
    { path:'signup/:username',component:SignupComponent, canActivate:[AuthGuardService] },
    { path: '', redirectTo: 'login', pathMatch: 'full' },

  ];
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    UserComponent,
    AdminComponent,
    SignupComponent,
    SampleComponent,
    HeaderComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    RouterModule.forRoot(routes)
  ],
  providers: [ DatePipe],
  bootstrap: [AppComponent]
})
export class AppModule { }
