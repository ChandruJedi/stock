-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema stock-exchange
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema stock-exchange
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `stock-exchange` DEFAULT CHARACTER SET utf8 ;
USE `stock-exchange` ;

-- -----------------------------------------------------
-- Table `stock-exchange`.`company`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `stock-exchange`.`company` (
  `co_id` INT(11) NOT NULL AUTO_INCREMENT,
  `co_name` VARCHAR(45) NULL DEFAULT NULL,
  `co_ceo` VARCHAR(45) NULL DEFAULT NULL,
  `co_stock_exchange` VARCHAR(45) NULL DEFAULT NULL,
  `co_turnover` FLOAT NULL DEFAULT NULL,
  `co_bod` VARCHAR(255) NULL DEFAULT NULL,
  `co_sector` VARCHAR(45) NULL DEFAULT NULL,
  `co_brief` VARCHAR(255) NULL DEFAULT NULL,
  `co_code` VARCHAR(45) NULL DEFAULT NULL,
  `co_active` TINYINT(1) NULL DEFAULT NULL,
  PRIMARY KEY (`co_id`))
ENGINE = InnoDB
AUTO_INCREMENT = 5
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `stock-exchange`.`ipo`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `stock-exchange`.`ipo` (
  `ip_id` INT(11) NOT NULL AUTO_INCREMENT,
  `ip_name` VARCHAR(45) NULL DEFAULT NULL,
  `ip_stock_exchange` BIGINT(11) NULL DEFAULT NULL,
  `ip_per_share` BIGINT(11) NULL DEFAULT NULL,
  `ip_total_share` INT(11) NULL DEFAULT NULL,
  `ip_open_time` DATETIME NULL DEFAULT NULL,
  `ip_remarks` VARCHAR(45) NULL DEFAULT NULL,
  PRIMARY KEY (`ip_id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `stock-exchange`.`role`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `stock-exchange`.`role` (
  `ro_id` INT(11) NOT NULL AUTO_INCREMENT,
  `ro_type` VARCHAR(45) NULL DEFAULT NULL,
  PRIMARY KEY (`ro_id`))
ENGINE = InnoDB
AUTO_INCREMENT = 3
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `stock-exchange`.`sectors`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `stock-exchange`.`sectors` (
  `se_id` INT(11) NOT NULL AUTO_INCREMENT,
  `se_name` VARCHAR(45) NULL DEFAULT NULL,
  `se_info` VARCHAR(255) NULL DEFAULT NULL,
  PRIMARY KEY (`se_id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `stock-exchange`.`stock_price`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `stock-exchange`.`stock_price` (
  `sp_id` INT(11) NOT NULL AUTO_INCREMENT,
  `sp_stock_exchange` VARCHAR(45) NULL DEFAULT NULL,
  `sp_current_price` FLOAT NULL DEFAULT NULL,
  `sp_date` DATE NULL DEFAULT NULL,
  `sp_time` TIME NULL DEFAULT NULL,
  `sp_code` VARCHAR(45) NULL DEFAULT NULL,
  PRIMARY KEY (`sp_id`))
ENGINE = InnoDB
AUTO_INCREMENT = 10
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `stock-exchange`.`user`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `stock-exchange`.`user` (
  `us_id` INT(11) NOT NULL AUTO_INCREMENT,
  `us_username` VARCHAR(45) NOT NULL,
  `us_password` VARCHAR(255) NOT NULL,
  `us_email` VARCHAR(45) NOT NULL,
  `us_mobile` VARCHAR(45) NOT NULL,
  `us_confirmed` TINYINT(1) NOT NULL,
  `us_ro_id` INT(11) NOT NULL,
  PRIMARY KEY (`us_id`),
  INDEX `fk_user_role_idx1` (`us_ro_id` ASC),
  CONSTRAINT `fk_user_role`
    FOREIGN KEY (`us_ro_id`)
    REFERENCES `stock-exchange`.`role` (`ro_id`))
ENGINE = InnoDB
AUTO_INCREMENT = 9
DEFAULT CHARACTER SET = utf8;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;


/*
-- Query: SELECT * FROM `stock-exchange`.role
LIMIT 0, 1000

*/
INSERT INTO `role` (`ro_id`,`ro_type`) VALUES (1,'ADMIN');
INSERT INTO `role` (`ro_id`,`ro_type`) VALUES (2,'USER');

/*
-- Query: SELECT * FROM `stock-exchange`.user
LIMIT 0, 1000

*/
INSERT INTO `user` (`us_id`,`us_username`,`us_password`,`us_email`,`us_mobile`,`us_confirmed`,`us_ro_id`) VALUES (1,'admin','$2a$10$R/lZJuT9skteNmAku9Y7aeutxbOKstD5xE5bHOf74M2PHZipyt3yK','chandru1197@gmail.com','9962607501',1,1);
INSERT INTO `user` (`us_id`,`us_username`,`us_password`,`us_email`,`us_mobile`,`us_confirmed`,`us_ro_id`) VALUES (7,'chandru','$2a$10$zxpgwCxZ.QohGcYhp5bkKeIeI/e6kziBFRIYOvC.SuFlSn/7S3plW','chandru1197@gmail.com','9871236544',0,2);
INSERT INTO `user` (`us_id`,`us_username`,`us_password`,`us_email`,`us_mobile`,`us_confirmed`,`us_ro_id`) VALUES (8,'user','$2a$10$1ImsqrywpcFEyAKbCT8eaOQB3sHqBVNVLHSaRJhNLAYtwiOo6iBGS','user@gmail.com','9874563214',1,2);

/*
-- Query: SELECT * FROM `stock-exchange`.company
LIMIT 0, 1000

*/
INSERT INTO `company` (`co_id`,`co_name`,`co_ceo`,`co_stock_exchange`,`co_turnover`,`co_bod`,`co_sector`,`co_brief`,`co_code`,`co_active`) VALUES (1,'Electronic Arts','Andrew Wilson','BSE, NSE',1231320,'Leonard S. Coleman, Jay C. Hoag','Gaming','Game Development Company','EA',1);
INSERT INTO `company` (`co_id`,`co_name`,`co_ceo`,`co_stock_exchange`,`co_turnover`,`co_bod`,`co_sector`,`co_brief`,`co_code`,`co_active`) VALUES (2,'Facebook','Mark Zuckerberg','BSE, NSE',5421341,'Marc L. Andreessen, Andreessen Horowitz','Social','Social Media Platform','FB',1);
INSERT INTO `company` (`co_id`,`co_name`,`co_ceo`,`co_stock_exchange`,`co_turnover`,`co_bod`,`co_sector`,`co_brief`,`co_code`,`co_active`) VALUES (3,'Microsoft','Satya Nadella','BSE, NSE',4245213,'William H. Gates III,Reid G. Hoffman','Software Solutions and Services','American multinational technology company','MS',1);
INSERT INTO `company` (`co_id`,`co_name`,`co_ceo`,`co_stock_exchange`,`co_turnover`,`co_bod`,`co_sector`,`co_brief`,`co_code`,`co_active`) VALUES (4,'Intel Corporation','Bob Swan','BSE, NSE',5322341,'Andy D. Principal, REH Advisors LLC','Hardware Solutions','Computer products and services','Intel',1);
