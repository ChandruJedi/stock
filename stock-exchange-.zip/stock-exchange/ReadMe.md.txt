Login Credentials :
	Admin : 
	Username - admin
	password - pwd
	User : 
	Username - chandru
	password - chandru

Important Note (Uploading Excel):
1. Upload the files in the required format.
2. Make sure that "Stock Exchange" in the Excel(uploading Excel) should be present in the Stock Exchange Detail. 
3. To Refer StockCode and StockExchange see in Manage Company and Manage Exchange
4. Make sure that "Stock Code" in the Excel(uploading Excel) should be present in the Stock Code in Company Detail.

 