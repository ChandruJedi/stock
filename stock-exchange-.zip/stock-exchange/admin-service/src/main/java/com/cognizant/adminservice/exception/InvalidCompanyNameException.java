package com.cognizant.adminservice.exception;

import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.http.HttpStatus;


@ResponseStatus(value = HttpStatus.BAD_REQUEST, reason = "Invalid company name exists in the document")
public class InvalidCompanyNameException extends Exception {

}
