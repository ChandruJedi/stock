package com.cognizant.adminservice.controller;


import java.io.IOException;
import java.sql.Time;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.cognizant.adminservice.bean.Company;
import com.cognizant.adminservice.bean.StockPrice;
import com.cognizant.adminservice.bean.Summary;
import com.cognizant.adminservice.exception.InvalidCompanyNameException;
import com.cognizant.adminservice.repository.CompanyRepository;
import com.cognizant.adminservice.repository.StockPriceRepository;



@RestController
public class ImportController {
	public String name;
	public Date start;
	public Date end;
//	private Date[] fullDate;
	
	private int recordSize=0;
	public String stockName;
	@Autowired StockPriceRepository stockPriceRepository;
	@Autowired CompanyRepository companyRepository;
	
	@PostMapping("/import")
	public void mapReapExcelDatatoDB(@RequestParam("file") MultipartFile reapExcelDataFile) throws IOException, InvalidCompanyNameException {
		System.out.println("hai");
		DataFormatter formatter = new DataFormatter();
		List<StockPrice> tempStudentList = new ArrayList<>();
		XSSFWorkbook workbook = new XSSFWorkbook(reapExcelDataFile.getInputStream());
		XSSFSheet worksheet = workbook.getSheetAt(0);
		List<Date> fullDate=new ArrayList<>();
		XSSFRow rows = worksheet.getRow(1);
		recordSize=worksheet.getPhysicalNumberOfRows();
		Company companyName= companyRepository.findByStockCode((String) rows.getCell(0).getStringCellValue());
		if(companyName==null) {
			throw new InvalidCompanyNameException();
		} else {
		for (int i = 1; i < worksheet.getPhysicalNumberOfRows(); i++) {
			StockPrice sp = new StockPrice();
			XSSFRow row = worksheet.getRow(i);
			sp.setCompanyCode((String) row.getCell(0).getStringCellValue().trim());
			sp.setPrice((float) row.getCell(2).getNumericCellValue());
			sp.setStockExchange((String) row.getCell(1).getStringCellValue().trim());
			sp.setDate((Date) row.getCell(3).getDateCellValue());
			sp.setTime(Time.valueOf(formatter.formatCellValue(row.getCell(4)).trim()));
			this.name=sp.getCompanyCode();
			fullDate.add(sp.getDate());
			this.stockName=sp.getStockExchange();
			tempStudentList.add(sp);
			stockPriceRepository.save(sp);
		}
		Collections.sort(fullDate);
		this.start=fullDate.get(0);
		this.end=fullDate.get(worksheet.getPhysicalNumberOfRows()-2);
		}
	}
	@GetMapping("/import")
	public Summary summary() {
				Summary summary=new Summary();
				summary.setName(this.name);
				summary.setLength(this.recordSize);
				summary.setStartDate(this.start);
				summary.setEndDate(this.end);
				summary.setStock(this.stockName);
				
				System.out.println(summary.toString());
				return summary;
	}
}