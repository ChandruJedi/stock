package com.cognizant.adminservice.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.cognizant.adminservice.bean.Role;
import com.cognizant.adminservice.bean.User;
import com.cognizant.adminservice.exception.UserAlreadyExistsException;
import com.cognizant.adminservice.repository.RoleRepository;
import com.cognizant.adminservice.repository.UserRepository;
import com.cognizant.adminservice.security.AppUser;

@Service
public class AppUserDetailsService implements UserDetailsService {
	private static final Logger LOGGER = LoggerFactory.getLogger(AppUserDetailsService.class);
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private RoleRepository roleRepository;
	public AppUserDetailsService(UserRepository userRepository) {
		super();
		this.userRepository = userRepository;
	}

	@Override
	public UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException {
		User user = userRepository.findByUsername(userName);
		LOGGER.info("Inside Service");
		if(user==null) {
			throw new UsernameNotFoundException("Username is not found");
		}else {
			return new AppUser(user);
		}	
	}
	public void signup(User user) throws UserAlreadyExistsException {
		User user1=userRepository.findByUsername(user.getUsername());
		if(user1!= null) {
			throw new UserAlreadyExistsException();
		}
		else {
			System.out.println(user.toString());
			user.setPassword(passwordEncoder().encode(user.getPassword()));
			Role roleObj = roleRepository.findById(2).get();
			user.setRole(roleObj);
			user.setConfirmed(true);
			userRepository.save(user);
		}
	}
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}
}
