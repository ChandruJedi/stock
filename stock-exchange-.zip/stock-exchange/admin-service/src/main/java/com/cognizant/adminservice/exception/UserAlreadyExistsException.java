package com.cognizant.adminservice.exception;

public class UserAlreadyExistsException extends Exception {

}
