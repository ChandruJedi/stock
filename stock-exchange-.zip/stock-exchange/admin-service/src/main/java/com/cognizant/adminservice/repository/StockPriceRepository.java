package com.cognizant.adminservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cognizant.adminservice.bean.StockPrice;

public interface StockPriceRepository extends JpaRepository<StockPrice,Integer> {

}
