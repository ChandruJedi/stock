package com.cognizant.adminservice.bean;

import java.util.Date;

public class Summary {
	private String name;
	private String stock;
	private Date startDate;
	private Date endDate;
	private int length;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getStock() {
		return stock;
	}
	public void setStock(String stock) {
		this.stock = stock;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public int getLength() {
		return length;
	}
	public void setLength(int length) {
		this.length = length;
	}
	@Override
	public String toString() {
		return "Summary [name=" + name + ", stock=" + stock + ", startDate=" + startDate + ", endDate=" + endDate
				+ ", length=" + length + "]";
	}
	

}
