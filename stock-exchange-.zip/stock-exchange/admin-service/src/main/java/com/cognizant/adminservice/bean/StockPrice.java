package com.cognizant.adminservice.bean;

import java.sql.Time;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="`stock_price`")
public class StockPrice {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "sp_id")
	private int id;
	@Column(name = "sp_code")
private String companyCode;
	@Column(name = "sp_stock_exchange")
private String stockExchange;
	@Column(name = "sp_current_price")
private float price;
	@Column(name = "sp_date")
private Date date;
	@Column(name = "sp_time")
private Time time;
public String getCompanyCode() {
	return companyCode;
}
public void setCompanyCode(String companyCode) {
	this.companyCode = companyCode;
}
public String getStockExchange() {
	return stockExchange;
}
public void setStockExchange(String stockExchange) {
	this.stockExchange = stockExchange;
}
public float getPrice() {
	return price;
}
public void setPrice(float price) {
	this.price = price;
}
public Date getDate() {
	return date;
}
public void setDate(Date date) {
	this.date = date;
}
public Time getTime() {
	return time;
}
public void setTime(Time time) {
	this.time = time;
}
@Override
public String toString() {
	return "StockPrice [companyCode=" + companyCode + ", stockExchange=" + stockExchange + ", price=" + price
			+ ", date=" + date + ", time=" + time + "]";
}

}
