package com.cognizant.adminservice;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class StockConstants {
	public static final Logger LOGGER= LoggerFactory.getLogger(StockConstants.class);
}
 