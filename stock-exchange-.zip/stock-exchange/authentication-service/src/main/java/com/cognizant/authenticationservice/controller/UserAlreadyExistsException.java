package com.cognizant.authenticationservice.controller;

public class UserAlreadyExistsException extends Exception {

}
