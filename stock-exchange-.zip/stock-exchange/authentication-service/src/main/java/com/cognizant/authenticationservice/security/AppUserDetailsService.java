package com.cognizant.authenticationservice.security;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.cognizant.authenticationservice.bean.Role;
import com.cognizant.authenticationservice.bean.User;
import com.cognizant.authenticationservice.controller.UserAlreadyExistsException;
import com.cognizant.authenticationservice.repository.RoleRepository;
import com.cognizant.authenticationservice.repository.UserRepository;




@Service
public class AppUserDetailsService implements UserDetailsService{
	@Autowired UserRepository userRepository;
	@Autowired RoleRepository roleRepository;
	@Override
	
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// TODO Auto-generated method stub
		User user = userRepository.findByUsername(username);
		if(user==null) {
			throw new UsernameNotFoundException("User not found!");
		}
		return new AppUser(user);
	}
	public AppUserDetailsService(UserRepository userRepository) {
		super();
		this.userRepository = userRepository;
	}
	public void signup(User user) throws UserAlreadyExistsException {
		if(user.getId()!=0) {
			User existedUser = userRepository.findById(user.getId()).get();
			if(user.getPassword()!=null) {
				existedUser.setPassword(passwordEncoder().encode(user.getPassword()));
			}
			if(user.getEmail()!=null) {
				existedUser.setEmail(user.getEmail());
			}
			if(user.getMobile()!=null) {
				existedUser.setMobile(user.getMobile());
			}
			userRepository.save(existedUser);
		}
		else {
			User user1=userRepository.findByUsername(user.getUsername());
			if(user1!= null) {
				throw new UserAlreadyExistsException();
			}
			else {
				System.out.println(user.toString());
				user.setPassword(passwordEncoder().encode(user.getPassword()));
				Role roleObj = roleRepository.findById(2).get();
				user.setRole(roleObj);
				user.setConfirmed(true);
				userRepository.save(user);
			} 
		}
	}
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}
	
	public User getUser(String username) {
		return this.userRepository.findByUsername(username);
	}
}
