package com.cognizant.authenticationservice;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Constants {
	public static final Logger LOGGER= LoggerFactory.getLogger(AuthenticationServiceApplication.class);
}
