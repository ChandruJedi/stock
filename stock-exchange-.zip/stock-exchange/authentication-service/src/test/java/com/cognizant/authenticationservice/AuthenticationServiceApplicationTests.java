package com.cognizant.authenticationservice;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

import org.junit.Test;
import org.mockito.Mockito;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.cognizant.authenticationservice.bean.Role;
import com.cognizant.authenticationservice.bean.User;
import com.cognizant.authenticationservice.repository.RoleRepository;
import com.cognizant.authenticationservice.repository.UserRepository;
import com.cognizant.authenticationservice.security.AppUserDetailsService;



//@RunWith(SpringRunner.class)
@SpringBootTest
public class AuthenticationServiceApplicationTests {

	//@Test
	public void contextLoads() {
	}
	private static final Logger LOGGER = LoggerFactory.getLogger(AuthenticationServiceApplicationTests.class);

	@Test
	public void mockTestLoadUserByUsername() {
		UserRepository repository = Mockito.mock(UserRepository.class);
		when(repository.findByUsername("dwad")).thenReturn(createUser());
		UserDetailsService service = new AppUserDetailsService(repository);
		UserDetails user = service.loadUserByUsername("dwad");
		String expected = "$2a$10$R/lZJuT9skteNmAku9Y7aeutxbOKstD5xE5bHOf74M2PHZipyt3yK";
		assertEquals(expected, user.getPassword());
	}

	@Test
	public void mockTestLoadByUserNameWithUserNull() {
		UserRepository repository = Mockito.mock(UserRepository.class);
		when(repository.findByUsername("user")).thenReturn(null);
		UserDetailsService service = new AppUserDetailsService(repository);
		try {
			UserDetails user = service.loadUserByUsername("usr1");
			LOGGER.debug("user:{}", user);
		} catch (UsernameNotFoundException e) {
			LOGGER.error("User not found", e);
			assertTrue(true);
			return;
		}
		assertFalse(true);
	}

	private User createUser() {
		User user = new User();
		Role role =new Role();
		role.setId(1);
		role.setName("ADMIN");
		user.setRole(role);
		user.setId(1);
		user.setUsername("usr1");
		user.setPassword("$2a$10$R/lZJuT9skteNmAku9Y7aeutxbOKstD5xE5bHOf74M2PHZipyt3yK");
		user.setRole(role);
		user.setMobile("7894561230l");
		user.setEmail("chan@gmail.com");
		return user;
	}

}
